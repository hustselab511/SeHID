import numpy as np
from scipy.signal import remez, filtfilt, find_peaks

# --- TIM J峰检测模型参数（尽量贴近论文实现） ---
# 论文原始采样率为 250 Hz，这里保留原函数接口 fs=125，内部自适应缩放时间参数
P_SAMPLES_AT_250HZ = 30          # 论文公式(2)中的 p=30 点
K_FACTOR = 2.0                  # 论文中经验设置 k=2
T_EPSILON_MS = 40               # 论文中 J 峰搜索容忍度 40 ms
DELTA_T_DEFAULT_MS = 80         # 当校准不足时的回退值（论文未给固定默认值，这里保留原代码意图）
LPF_CUTOFF_HZ = 1.8             # 论文结果最优平滑截止频率
LPF_TAPS = 200                  # 论文 x_DET 平滑 FIR 滤波器长度 M=200
BPF_ORDER = 1024                # 论文预处理 FIR 阶数
CALIBRATION_DURATION_SEC = 60   # 论文：静息校准 1 min


def _to_numpy_1d(x):
    if hasattr(x, 'detach'):
        x = x.detach()
    if hasattr(x, 'cpu'):
        x = x.cpu().numpy()
    x = np.asarray(x).squeeze()
    if x.ndim != 1:
        raise ValueError('bcg_signal must be 1-D after squeeze().')
    return x.astype(float, copy=False)


def _safe_zscore(x):
    std = np.std(x)
    if std < 1e-12:
        return np.zeros_like(x)
    return (x - np.mean(x)) / std


def _design_bandpass_fir(fs, numtaps=BPF_ORDER):
    nyq = fs / 2.0
    # 使用 remez 近似论文中的 Parks–McClellan FIR 设计
    bands = [0.0, 1.5, 2.0, 14.0, 14.5, nyq]
    desired = [0.0, 1.0, 0.0]
    weights = [1.0, 1.0, 1.0]
    return remez(numtaps, bands, desired, weight=weights, fs=fs)


def _design_lowpass_fir(fs, cutoff_hz=LPF_CUTOFF_HZ, numtaps=LPF_TAPS):
    nyq = fs / 2.0
    stop = min(cutoff_hz + 0.4, nyq - 1e-3)
    if stop <= cutoff_hz:
        stop = min(cutoff_hz * 1.2, nyq - 1e-3)
    bands = [0.0, cutoff_hz, stop, nyq]
    desired = [1.0, 0.0]
    weights = [1.0, 1.0]
    return remez(numtaps, bands, desired, weight=weights, fs=fs)


def tim_preprocess(bcg_signal, fs):
    """
    占位函数：若输入已完成外部预处理，则直接返回。
    保留该函数仅为兼容原代码结构。
    """
    return _to_numpy_1d(bcg_signal)


def calculate_x_det(bcg_preprocessed, fs, lpf_cutoff=LPF_CUTOFF_HZ, lpf_taps=LPF_TAPS):
    """
    x_DET[n] = sum_k b[k] * x_BCG^2[n-k]
    """
    bcg_preprocessed = _to_numpy_1d(bcg_preprocessed)
    bcg_squared = np.square(bcg_preprocessed)

    if len(bcg_squared) < lpf_taps * 3:
        return bcg_squared.copy()

    fir_lpf = _design_lowpass_fir(fs=fs, cutoff_hz=lpf_cutoff, numtaps=lpf_taps)
    return filtfilt(fir_lpf, [1.0], bcg_squared)


def _extract_positive_intervals(x_sqr):
    intervals = []
    start = None
    for i, v in enumerate(x_sqr):
        if v > 0 and start is None:
            start = i
        elif v <= 0 and start is not None:
            intervals.append([start, i - 1])
            start = None
    if start is not None:
        intervals.append([start, len(x_sqr) - 1])
    return intervals


def calculate_x_sqr(x_det, fs, p_duration_ms=None, k=K_FACTOR):
    """
    论文公式(2)：x_DET[i] >= mu(i-p:i) + k*sigma(i-p:i) 时标为 +1，否则 -1。
    如果传入 p_duration_ms，则优先按时间换算；否则按论文 p=30@250Hz 做等比例缩放。
    """
    x_det = _to_numpy_1d(x_det)
    n = len(x_det)
    x_sqr = -np.ones(n, dtype=np.int8)

    if p_duration_ms is None:
        p_samples = max(1, int(round(P_SAMPLES_AT_250HZ * fs / 250.0)))
    else:
        p_samples = max(1, int(round(p_duration_ms * fs / 1000.0)))

    for i in range(p_samples, n):
        window = x_det[i - p_samples:i]
        mu_local = np.mean(window)
        sigma_local = np.std(window)
        if x_det[i] >= mu_local + k * sigma_local:
            x_sqr[i] = 1

    return x_sqr, _extract_positive_intervals(x_sqr)


def _interval_duration_stats(intervals):
    if not intervals:
        return None, None
    durations = np.array([end - start + 1 for start, end in intervals], dtype=float)
    median = np.median(durations)
    mad = np.median(np.abs(durations - median))
    robust_std = 1.4826 * mad if mad > 0 else max(1.0, np.std(durations))
    return median, robust_std


def _negative_intervals_from_positive(positive_intervals, n_samples):
    negatives = []
    prev_end = -1
    for start, end in positive_intervals:
        if start - prev_end > 1:
            negatives.append([prev_end + 1, start - 1])
        prev_end = end
    if prev_end < n_samples - 1:
        negatives.append([prev_end + 1, n_samples - 1])
    return negatives


def refine_candidate_intervals(x_det, x_sqr, candidate_intervals, fs, base_k=K_FACTOR):
    """
    对论文提到的 second-pass refinement 做可执行近似：
    1) 过长正区间尝试按局部谷值切分；
    2) 过长负区间通过降低 k 重新搜索弱峰。
    返回新的 x_sqr 和候选正区间。
    """
    x_det = _to_numpy_1d(x_det)
    x_sqr = np.array(x_sqr, copy=True)
    intervals = [list(itv) for itv in candidate_intervals]
    if not intervals:
        return x_sqr, intervals

    pos_med, pos_std = _interval_duration_stats(intervals)
    if pos_med is None:
        return x_sqr, intervals

    # 1) split too-long positive intervals
    refined = []
    for start, end in intervals:
        dur = end - start + 1
        if dur > pos_med + 2.0 * pos_std and dur > 3:
            seg = x_det[start:end + 1]
            valley_rel = int(np.argmin(seg))
            valley = start + valley_rel
            left_len = valley - start
            right_len = end - valley
            if left_len >= max(2, int(0.25 * pos_med)) and right_len >= max(2, int(0.25 * pos_med)):
                x_sqr[valley] = -1
                refined.append([start, valley - 1])
                refined.append([valley + 1, end])
            else:
                refined.append([start, end])
        else:
            refined.append([start, end])

    intervals = [itv for itv in refined if itv[0] <= itv[1]]
    neg_intervals = _negative_intervals_from_positive(intervals, len(x_det))
    neg_med, neg_std = _interval_duration_stats(neg_intervals)

    # 2) inspect too-long negative intervals with reduced k
    if neg_med is not None:
        p_samples = max(1, int(round(P_SAMPLES_AT_250HZ * fs / 250.0)))
        reduced_k = max(0.5, base_k * 0.5)
        for start, end in neg_intervals:
            dur = end - start + 1
            if dur <= neg_med + 2.0 * neg_std:
                continue
            for i in range(max(start, p_samples), end + 1):
                window = x_det[i - p_samples:i]
                mu_local = np.mean(window)
                sigma_local = np.std(window)
                if x_det[i] >= mu_local + reduced_k * sigma_local:
                    x_sqr[i] = 1

    return x_sqr, _extract_positive_intervals(x_sqr)


def _local_max_index(signal, start, end):
    seg = signal[start:end + 1]
    if seg.size == 0:
        return None
    peaks, _ = find_peaks(seg)
    if len(peaks) == 0:
        return start + int(np.argmax(seg))
    return start + int(peaks[np.argmax(seg[peaks])])


def calibrate_delta_t(bcg_preprocessed, x_det, candidate_intervals, fs, t_epsilon=T_EPSILON_MS, default_delta_t_ms=DELTA_T_DEFAULT_MS):
    """
    论文校准：统计每个候选区间中 x_DET 最大值与 x_BCG 最显著峰的距离中位数 t_J,DET。
    """
    bcg_preprocessed = _to_numpy_1d(bcg_preprocessed)
    x_det = _to_numpy_1d(x_det)
    t_epsilon_samples = max(1, int(round(t_epsilon * fs / 1000.0)))
    default_delta_t_samples = int(round(default_delta_t_ms * fs / 1000.0))

    delta_t_list = []
    j_pos_list = []
    for start, end in candidate_intervals:
        det_max_pos = _local_max_index(x_det, start, end)
        if det_max_pos is None:
            continue

        search_start = max(start, det_max_pos - t_epsilon_samples)
        search_end = min(end, det_max_pos + t_epsilon_samples)
        j_pos = _local_max_index(bcg_preprocessed, search_start, search_end)
        if j_pos is None:
            continue

        delta_t_list.append(det_max_pos - j_pos)
        j_pos_list.append(j_pos)

    if len(delta_t_list) == 0:
        delta_t_j_det = default_delta_t_samples
    else:
        delta_t_j_det = int(round(np.median(delta_t_list)))

    return delta_t_j_det, np.array(sorted(set(j_pos_list)), dtype=int)


def locate_j_peaks(bcg_preprocessed, x_det, candidate_intervals, delta_t_j_det, fs, t_epsilon=T_EPSILON_MS, default_delta_t_ms=DELTA_T_DEFAULT_MS):
    """
    在每个正区间内先找 x_DET 局部最大值，再依据校准距离在 x_BCG 中找 J 峰。
    """
    bcg_preprocessed = _to_numpy_1d(bcg_preprocessed)
    x_det = _to_numpy_1d(x_det)
    t_epsilon_samples = max(1, int(round(t_epsilon * fs / 1000.0)))

    raw_j_peaks = []
    for start, end in candidate_intervals:
        det_max_pos = _local_max_index(x_det, start, end)
        if det_max_pos is None:
            continue

        j_expected_pos = det_max_pos - delta_t_j_det
        search_start = max(start, j_expected_pos - t_epsilon_samples)
        search_end = min(end, j_expected_pos + t_epsilon_samples)
        j_pos = _local_max_index(bcg_preprocessed, search_start, search_end)
        if j_pos is not None:
            raw_j_peaks.append(j_pos)

    if not raw_j_peaks:
        return np.array([], dtype=int)
    return np.array(sorted(set(raw_j_peaks)), dtype=int)


def post_process_j_peaks(j_peaks, bcg_preprocessed, x_det, fs):
    """
    基于论文的 refinement 思想做后处理：
    - 删除过近假峰；
    - 对过长间隔尝试在中间用 x_DET 补检一个弱峰。
    """
    j_peaks = np.asarray(j_peaks, dtype=int)
    if len(j_peaks) < 2:
        return j_peaks

    bcg_preprocessed = _to_numpy_1d(bcg_preprocessed)
    x_det = _to_numpy_1d(x_det)

    rr_like = np.diff(j_peaks)
    median_jj = np.median(rr_like)
    if median_jj <= 0:
        return j_peaks

    min_sep = max(1, int(round(0.3 * median_jj)))

    kept = [int(j_peaks[0])]
    for j in j_peaks[1:]:
        if j - kept[-1] >= min_sep:
            kept.append(int(j))
        else:
            # 过近则保留 x_BCG 幅值更高者
            if bcg_preprocessed[j] > bcg_preprocessed[kept[-1]]:
                kept[-1] = int(j)

    refined = [kept[0]]
    long_thr = 1.5 * median_jj
    for j in kept[1:]:
        prev = refined[-1]
        gap = j - prev
        if gap > long_thr:
            mid_start = prev + int(round(0.25 * gap))
            mid_end = j - int(round(0.25 * gap))
            if mid_end > mid_start + 2:
                det_mid = _local_max_index(x_det, mid_start, mid_end)
                if det_mid is not None:
                    local_half = max(1, int(round(T_EPSILON_MS * fs / 1000.0)))
                    cand_start = max(mid_start, det_mid - local_half)
                    cand_end = min(mid_end, det_mid + local_half)
                    mid_j = _local_max_index(bcg_preprocessed, cand_start, cand_end)
                    if mid_j is not None and (mid_j - prev) >= min_sep and (j - mid_j) >= min_sep:
                        refined.append(int(mid_j))
        refined.append(int(j))

    return np.array(sorted(set(refined)), dtype=int)


def tim_bcg_jpeak_detect(bcg_signal, fs=125):
    """
    TIM 论文 BCG J 峰检测主函数。
    输入输出接口保持不变：输入 1-D BCG，输出原始采样率下的 J 峰索引数组。

    该版本默认输入已经完成外部预处理，因此这里不再重复实现论文中的
    2-14 Hz FIR + z-score，而聚焦于论文的核心检测流程：
    1) 构造 x_DET = LPF(x_BCG^2)；
    2) 用 x_SQR 提取候选正区间；
    3) second-pass refinement；
    4) 个体校准 t_J,DET；
    5) 在候选区间内定位 J 峰并做后处理。
    """
    bcg_signal = _to_numpy_1d(bcg_signal)
    if len(bcg_signal) == 0:
        return np.array([], dtype=int)

    # 为了兼容原接口，若 fs 与论文不同，不改输出接口，只在内部按当前 fs 自适应处理。
    bcg_preprocessed = tim_preprocess(bcg_signal, fs=fs)
    x_det = calculate_x_det(bcg_preprocessed, fs=fs)

    x_sqr, candidate_intervals = calculate_x_sqr(x_det, fs=fs, p_duration_ms=None, k=K_FACTOR)
    if len(candidate_intervals) == 0:
        return np.array([], dtype=int)

    x_sqr, candidate_intervals = refine_candidate_intervals(x_det, x_sqr, candidate_intervals, fs=fs, base_k=K_FACTOR)
    if len(candidate_intervals) == 0:
        return np.array([], dtype=int)

    # 论文使用 1 分钟静息片段做校准；若输入不足 1 分钟，则退化为用全段校准。
    calibration_len = min(len(bcg_preprocessed), int(round(CALIBRATION_DURATION_SEC * fs)))
    calib_intervals = [
        [s, e] for s, e in candidate_intervals
        if s < calibration_len and e >= 0
    ]
    calib_intervals = [[s, min(e, calibration_len - 1)] for s, e in calib_intervals if s <= calibration_len - 1]
    if len(calib_intervals) == 0:
        calib_intervals = candidate_intervals

    delta_t_j_det, _ = calibrate_delta_t(
        bcg_preprocessed[:calibration_len],
        x_det[:calibration_len],
        calib_intervals,
        fs=fs,
        t_epsilon=T_EPSILON_MS,
        default_delta_t_ms=DELTA_T_DEFAULT_MS,
    )

    raw_j_peaks = locate_j_peaks(
        bcg_preprocessed,
        x_det,
        candidate_intervals,
        delta_t_j_det,
        fs=fs,
        t_epsilon=T_EPSILON_MS,
        default_delta_t_ms=DELTA_T_DEFAULT_MS,
    )
    if len(raw_j_peaks) == 0:
        return np.array([], dtype=int)

    final_j_peaks = post_process_j_peaks(raw_j_peaks, bcg_preprocessed, x_det, fs=fs)
    final_j_peaks = final_j_peaks[(final_j_peaks >= 0) & (final_j_peaks < len(bcg_signal))]
    return np.array(sorted(set(final_j_peaks.tolist())), dtype=int)

if __name__ == "__main__":
    # 模拟输入 (B, C, T)
    x = np.random.rand(1, 1, 625)

    # 取单条信号
    signal = x[0, 0]

    # 调用模型
    peaks = tim_bcg_jpeak_detect(signal, fs=125)

    # 输出结果
    print("Input shape:", x.shape)
    print("Detected J-peaks:", peaks)
    print("Number of peaks:", len(peaks))

